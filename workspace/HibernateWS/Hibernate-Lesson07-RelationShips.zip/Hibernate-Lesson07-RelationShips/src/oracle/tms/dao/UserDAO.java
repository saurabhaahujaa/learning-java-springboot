package oracle.tms.dao;

import oracle.tms.entities.UserEO;

public interface UserDAO {
	
	public String insertUser(UserEO userEORef);
}
